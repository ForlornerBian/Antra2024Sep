namespace ConsoleApp4;

public delegate int MathDelegate(int a, int b);
